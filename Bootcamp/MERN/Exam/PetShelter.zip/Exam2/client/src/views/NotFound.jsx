export const NotFound = (props) => {
    return <h2>page not found</h2>
}