from flask import Flask 
app = Flask(__name__)
app.secret_key = 'bruh sound effect #12'
DATABASE = 'sasquatch_db'